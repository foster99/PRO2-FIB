var searchData=
[
  ['quitar_5fitems',['quitar_items',['../class_almacen.html#a16de14cab27a1789eeecc23abfeacc5a',1,'Almacen::quitar_items()'],['../class_sala.html#a4e449719446b07b4626c8502a87a5af2',1,'Sala::quitar_items()']]],
  ['quitar_5fprod',['quitar_prod',['../class_almacen.html#a1899609156ebe6d1bca071dd4fea5eb2',1,'Almacen']]]
];
