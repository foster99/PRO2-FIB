var searchData=
[
  ['inventario',['inventario',['../class_almacen.html#affa9fb3647b6cdb13184371dd9e32454',1,'Almacen']]]
];
