var searchData=
[
  ['sala',['Sala',['../class_sala.html',1,'']]]
];
