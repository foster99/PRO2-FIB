var searchData=
[
  ['poner_5fitems',['poner_items',['../class_almacen.html#a0718beb9b0ed5272d030ac2c0b72364d',1,'Almacen::poner_items()'],['../class_sala.html#a748f6e7dd49a9c5f67623640f774e0ff',1,'Sala::poner_items()']]],
  ['poner_5fprod',['poner_prod',['../class_almacen.html#a5ceb8f70af951fdd3c961e693fa2f53d',1,'Almacen']]]
];
