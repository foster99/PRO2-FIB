var searchData=
[
  ['escribir',['escribir',['../class_almacen.html#adabb9eae94dd8fb804f2eea351c175fa',1,'Almacen::escribir()'],['../class_sala.html#afd8421dde833322ed676c232e88cb77c',1,'Sala::escribir()']]]
];
