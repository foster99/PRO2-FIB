var searchData=
[
  ['sala',['Sala',['../class_sala.html',1,'Sala'],['../class_sala.html#ab6f672b31658edd49b5d409bf9fbe659',1,'Sala::Sala()']]],
  ['sala_2ehh',['Sala.hh',['../_sala_8hh.html',1,'']]]
];
