var searchData=
[
  ['almacen',['Almacen',['../class_almacen.html',1,'Almacen'],['../class_almacen.html#ab6569f621c050df752fcdf5e1614631e',1,'Almacen::Almacen()']]],
  ['almacen_2ehh',['Almacen.hh',['../_almacen_8hh.html',1,'']]],
  ['asignacion_5fdimensiones_5festanteria',['asignacion_dimensiones_estanteria',['../class_sala.html#a1b8b14baf2acaf5a118fc0e426fc107d',1,'Sala']]]
];
