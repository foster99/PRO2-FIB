var searchData=
[
  ['lectura_5fdimensiones_5fsalas',['lectura_dimensiones_salas',['../class_almacen.html#a25ae2690b3295f66fa5798c01b7ab182',1,'Almacen']]]
];
