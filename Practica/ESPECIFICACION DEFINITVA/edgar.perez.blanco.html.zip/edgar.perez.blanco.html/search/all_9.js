var searchData=
[
  ['redimensionar',['redimensionar',['../class_almacen.html#a873095b67a174bc27fd473043fef2a25',1,'Almacen::redimensionar()'],['../class_sala.html#abed3d192d416f7f14be6e8597f5e6059',1,'Sala::redimensionar()']]],
  ['reorganizar',['reorganizar',['../class_almacen.html#acb6e13d2501688e17607b4a74fb18cf8',1,'Almacen::reorganizar()'],['../class_sala.html#aaac8d848595b493ea08516f2101b829e',1,'Sala::reorganizar()']]]
];
